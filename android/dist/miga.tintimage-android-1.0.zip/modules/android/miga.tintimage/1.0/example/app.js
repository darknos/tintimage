var tintimage = require('miga.tintimage');

var window = Ti.UI.createWindow({
    backgroundColor: 'white'
});

